<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <consultar.phpmeta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envíos Seguros</title>

    <link href="../cdn.jsdelivr.net/npm/bootstrap%405.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="../cdn.jsdelivr.net/npm/bootstrap%405.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div>
        <img src="img/1.jfif" alt="" width="100%">

        <!-- Carrusel -->
        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/s1.webp" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="img/s2.webp" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="img/s3.webp" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="img/s4.webp" class="d-block w-100" alt="...">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>
    </div>

    <br><img src="img/2.jfif" alt="" width="100%">

    <div class="envio">
        <form action="consultar.php" method="GET">
            <center>
                <input type="text" id="nGuia" name="guia" placeholder="Ingresa el No. de guía" required>
                <br><br>

                <label>
                    <input type="checkbox" name="aceptar_terminos" required>
                    Acepto términos y condiciones
                </label>

                <br><br>
                <img src="img/3.jfif" alt="" width="100%">
                <br>
                <input type="submit" value="Consultar" id="btn">
            </center>
        </form>
    </div>

    <footer>
        <br><img src="img/4.jfif" alt="" width="100%"><br>
        <img src="img/5.jfif" alt="" width="100%">
        <img src="img/6.jfif" alt="" width="100%">

        <div style="background-color:#0164b7;">
            <center>
                <img src="img/7.jfif" alt="" width="98%">
                <img src="img/8.jfif" alt="" width="98%">
                <img src="img/9.jfif" alt="" width="98%">
            </center>
            <img src="img/10.jfif" alt="" width="100%">
        </div>
        <img src="img/f1.jpg" alt="" width="100%">
        <img src="img/f2.jpg" alt="" width="100%">
        <img src="img/f3.jpg" alt="" width="100%">
        <img src="img/f4.jpg" alt="" width="100%">
        <img src="img/f5.jpg" alt="" width="100%">
    </footer>

</body>
</html>
